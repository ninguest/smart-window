import RPi.GPIO as GPIO
import time
import sys

def setup():
    in1 = 6
    in2 = 13
    in3 = 19
    in4 = 26

    # careful lowering this, at some point you run into the mechanical limitation of how quick your motor can move
    step_sleep = 0.002

    step_count = 1024  # 5.625*(1/64) per step, 4096 steps is 360°

    direction = True  # True for counter-clockwise (Open window), False for clockwise(Close Window)

    # defining stepper motor sequence (found in documentation http://www.4tronix.co.uk/arduino/Stepper-Motors.php)
    step_sequence = [[1, 0, 0, 0],
                     [1, 1, 0, 0],
                     [0, 1, 0, 0],
                     [0, 1, 1, 0],
                     [0, 0, 1, 0],
                     [0, 0, 1, 1],
                     [0, 0, 0, 1],
                     [1, 0, 0, 1]]

    # setting up
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(in1, GPIO.OUT)
    GPIO.setup(in2, GPIO.OUT)
    GPIO.setup(in3, GPIO.OUT)
    GPIO.setup(in4, GPIO.OUT)

    # initializing
    GPIO.output(in1, GPIO.LOW)
    GPIO.output(in2, GPIO.LOW)
    GPIO.output(in3, GPIO.LOW)
    GPIO.output(in4, GPIO.LOW)

    motor_pins = [in1, in2, in3, in4]

    return step_sleep, step_count, motor_pins, step_sequence


def cleanup(motor_pins):
    GPIO.output(motor_pins[0], GPIO.LOW)
    GPIO.output(motor_pins[1], GPIO.LOW)
    GPIO.output(motor_pins[2], GPIO.LOW)
    GPIO.output(motor_pins[3], GPIO.LOW)
    GPIO.cleanup()


def motor(window):
    #print(sys.argv[1])
    #window = bool(sys.argv[1])
    step_sleep, step_count, motor_pins, step_sequence = setup()
    motor_step_counter = 0

    try:
        i = 0
        for i in range(step_count):
            for pin in range(0, len(motor_pins)):
                GPIO.output(motor_pins[pin], step_sequence[motor_step_counter][pin])
            if window == True:
                motor_step_counter = (motor_step_counter - 1) % 8
            elif window == False:
                motor_step_counter = (motor_step_counter + 1) % 8
            time.sleep(step_sleep)
    except Exception as e:  # defensive programming
        print("uh oh... an error has occurred")
        print(e)
        cleanup(motor_pins)
        exit(1)
    except KeyboardInterrupt:
        cleanup(motor_pins)
        exit(1)
    cleanup(motor_pins)


if __name__ == "__main__":
    motor(True)
