import RPi.GPIO as GPIO
import time
import sys
import json
import os



def setup():
    in1 = 6
    in2 = 13
    in3 = 19
    in4 = 26
    # careful lowering this, at some point you run into the mechanical limitation of how quick your motor can move
    step_sleep = 0.002

    step_count = 1024  # 5.625*(1/64) per step, 4096 steps is 360°

    direction = True  # True for counter-clockwise (Open window), False for clockwise(Close Window)

    # defining stepper motor sequence (found in documentation http://www.4tronix.co.uk/arduino/Stepper-Motors.php)
    step_sequence = [[1, 0, 0, 0],
                     [1, 1, 0, 0],
                     [0, 1, 0, 0],
                     [0, 1, 1, 0],
                     [0, 0, 1, 0],
                     [0, 0, 1, 1],
                     [0, 0, 0, 1],
                     [1, 0, 0, 1]]

    # setting up
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(in1, GPIO.OUT)
    GPIO.setup(in2, GPIO.OUT)
    GPIO.setup(in3, GPIO.OUT)
    GPIO.setup(in4, GPIO.OUT)

    # initializing
    GPIO.output(in1, GPIO.LOW)
    GPIO.output(in2, GPIO.LOW)
    GPIO.output(in3, GPIO.LOW)
    GPIO.output(in4, GPIO.LOW)

    motor_pins = [in1, in2, in3, in4]

    return step_sleep, step_count, motor_pins, step_sequence


def cleanup(motor_pins):
    GPIO.output(motor_pins[0], GPIO.LOW)
    GPIO.output(motor_pins[1], GPIO.LOW)
    GPIO.output(motor_pins[2], GPIO.LOW)
    GPIO.output(motor_pins[3], GPIO.LOW)
    GPIO.cleanup()


# Read Data
def read_json_file(file_path, component):
    try:
        with open(file_path) as f:
            data = json.load(f)
            if component == "window":
                return data["Window_state"]
            elif component == "light":
                return data["Light_state"]
    except Exception as e:
        print(f"Error writing to file: {e}")

def write_json_file(file_path, component, command):
    light_state = read_json_file(file_path, "light")
    window_state = read_json_file(file_path, "window")

    if component == "window":
        data = {
            "Window_state": command,
            "Light_state": light_state
        }
    
    if component == "light":
        data = {
            "Window_state": window_state,
            "Light_state": command
        }
        
    try:
        with open(file_path, "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Error writing to file: {e}")


def motor(window):
    data_file = "comp_data.json"
    current_window_state = read_json_file(data_file, "window")
    print(current_window_state, window)
    # if the window is already in the desired state, do nothing
    if current_window_state == "open" and window == True:
        print("Window is already open")
        return
    elif current_window_state == "close" and window == False:
        print("Window is already closed")
        return

    step_sleep, step_count, motor_pins, step_sequence = setup()
    motor_step_counter = 0

    #if window == True:
        #write_json_file(data_file,"window", "open")
    #elif window == False:
        #write_json_file(data_file,"window", "close")
        
    try:
        i = 0
        for i in range(step_count):
            for pin in range(0, len(motor_pins)):
                GPIO.output(motor_pins[pin], step_sequence[motor_step_counter][pin])
            if window == True:
                motor_step_counter = (motor_step_counter - 1) % 8
            elif window == False:
                motor_step_counter = (motor_step_counter + 1) % 8
            time.sleep(step_sleep)
    except Exception as e:  # defensive programming
        print("uh oh... an error has occurred")
        print(e)
        cleanup(motor_pins)
        exit(1)
    except KeyboardInterrupt:
        cleanup(motor_pins)
        exit(1)
    cleanup(motor_pins)

def light(light):
    data_file = "comp_data.json"
    current_light_state = read_json_file(data_file, "light")

    if current_light_state == "on" and light == True:
        print("Light is already on")
        return
    elif current_light_state == "off" and light == False:
        print("Light is already off")
        return


    GPIO.setmode(GPIO.BCM)

    port = 18


    GPIO.setup(port, GPIO.OUT)
    GPIO.output(port, GPIO.LOW)
    if light == True:
        GPIO.output(port, GPIO.HIGH)
        write_json_file("data.json", "light", "on")
        print("Light turns on")
    elif light == False:
        GPIO.output(port, GPIO.LOW)
        write_json_file("data.json", "light", "off")
        print("Light turns off")

    # GPIO.cleanup()

def testLight(bool):
    GPIO.setmode(GPIO.BCM)
    GPIO.setwarnings(False)
    GPIO.setup(18,GPIO.OUT)
    
    if bool:
      print("LED on")
      GPIO.output(18,GPIO.HIGH)
    else:
      print("LED off")
      GPIO.output(18,GPIO.LOW)
    #time.sleep(5)
    
if __name__ == "__main__":
    testLight(False)
    #light(True)
    #time.sleep(1)
    #light(False)
    #GPIO.cleanup()

    