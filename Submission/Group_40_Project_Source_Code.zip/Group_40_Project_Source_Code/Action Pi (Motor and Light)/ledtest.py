import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

port = 18

GPIO.setup(port, GPIO.OUT)

x = 0
rep = 2
while x < rep:
	GPIO.output(port, GPIO.HIGH)
	print("Light turns on")
	time.sleep(1)

	GPIO.output(port, GPIO.LOW)
	print("Light turns off")
	time.sleep(1)
	x += 1

GPIO.cleanup()
