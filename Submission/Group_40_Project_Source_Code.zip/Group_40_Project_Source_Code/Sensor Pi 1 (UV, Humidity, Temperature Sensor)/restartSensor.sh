#!/bin/bash

# Restart the sensor
pm2 restart sensor  # If you're using pm2 for process management